Only Up for Windows

1. Unzip this folder (right-click > Extract All).
2. Double-click OnlyUp.exe.
3. If Windows says "Windows protected your PC", click More info > Run anyway.

The app downloads the newest version of Only Up each time it opens, so you never need to download it again.
Your progress in the app is separate from the website. Use your link code in Profile to bring it over.
